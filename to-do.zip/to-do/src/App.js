import React from 'react'

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      currentTime:''
    };
  }

  addItem = (e) => {
    e.preventDefault();
    let list = this.state.list;
    let newTime = this.state.currentTime;
    newTime = new Date();
    const time = newTime.toLocaleTimeString();
    const times = [...this.state.currentTime, time];
    const newItem = document.getElementById("addInput");
    const form = document.getElementById("addItemForm");

     if (newItem.value !== "") {
    
      list.push(newItem.value);
   
      this.setState({
        list: list,
        currentTime: times
      });
      form.reset();
    } 
  }

  render() {
    return (
      <div>
        <div >
         <form  id="addItemForm">
            <input
              type="text"
              id="addInput"
              placeholder="Enter Items"
              maxLength={30}
            />
            <button  onClick={this.addItem}>
              Add Item
            </button>
            <List items={this.state.list} times={this.state.currentTime} />
          </form>
        </div>
      </div>
    );
  }
}

class List extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			filtered: []
		};
	}
	
	componentDidMount() {
    this.setState({
      filtered: this.props.items
    });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      filtered: nextProps.items
    });
  }
	
	handleChange = (e) => {

    let currentList = [];

    let newList = [];
		
	
    if (e.target.value !== "") {
		
      currentList = this.props.items;
      newList = currentList.filter(item => {
			
        const lc = item.toLowerCase();
			
        const filter = e.target.value.toLowerCase();
        return lc.includes(filter);
      });
    } else {
      newList = this.props.items;
    }
    this.setState({
      filtered: newList
    });
  }
	
	render() {
    const time = this.props.times
		return (
			<div>
				<input type="text" className="input" onChange={this.handleChange} placeholder="Search..." />
					<table>
            <tr>
              <td>
              {this.state.filtered.map(item => (
							<p key={item}>
								{item} 
							</p>
						  ))}
			        </td>
              <td>
                {time}
              </td>
            </tr>
          </table>
				</div>
		)
	}
}

export default App;