import React from 'react';
import './App.css'

const ListItems = (props) => {
    const items = props.items;
    const timecurr = props.times;

    const listItems = items.map((item) => {
        return <tr key={item.key}><td>{item.text}</td></tr>
    })
    return (
        <>
            <p>{listItems}</p>
             <p>{timecurr}</p>
        </>
    )
}

export default ListItems;
