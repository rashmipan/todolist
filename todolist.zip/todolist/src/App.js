import React, { Component } from 'react';
import InputItems from './InputItems';

class App extends Component{
  render(){
    return(
      <InputItems/>
    )
  }
}

export default App;
