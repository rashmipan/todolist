import React, { Component } from 'react';
import ListItems from './ListItems';
import SearchBox from './SearchBox';

class InputItems extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      currentItem: {
        text: '',
        key: ''
      },
      currentTime: ''
    }
  }
  changeHandler = (e) => {
    this.setState({
      currentItem: {
        text: e.target.value,
        key: 1 * Math.random()
      }
    })
  }

  addItems = (e) => {
    e.preventDefault();
    const newItem = this.state.currentItem;
    let newTime = this.state.currentTime;
    newTime = new Date();
    const time = newTime.toLocaleTimeString();
    if (newItem.text !== "") {
      const items = [...this.state.items, newItem];
      const times = [...this.state.currentTime, time];
      this.setState({
        items: items,
        currentItem: {
          text: '',
          key: ''
        },
        currentTime: times
      })
    }
  }

  render() {
    return (
      <>
        <form onSubmit={this.addItems}>
          <input
            type="text"
            placeholder="Enter Items"
            value={this.state.currentItem.text}
            onChange={this.changeHandler}
            maxLength={30}
          />
          <button type="submit">Add Items</button>
        </form>
        <ListItems items={this.state.items} times={this.state.currentTime} />
        <SearchBox items={this.state.items} />
      </>
    );
  }
}

export default InputItems;